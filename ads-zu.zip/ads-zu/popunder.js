// Fungsi untuk pop under
function popUnder(url) {
    var win = window.open(url, '_blank');
    win.blur();
    window.focus();
}

// Pop under setelah 3 detik pertama
setTimeout(function() {
    popUnder('https://www.example.com');
    
    // Pop under setiap 30 detik
    setInterval(function() {
        popUnder('https://www.example.com');
    }, 120000); // 2 menit
}, 5500); // 5,5 detik
