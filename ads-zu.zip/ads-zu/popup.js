// Function to show the popup
function showPopup() {
  var popup = document.getElementById('popup');
  popup.style.display = 'block';
}

// Function to hide the popup
function hidePopup() {
  var popup = document.getElementById('popup');
  popup.style.display = 'none';
}

// Function to open a new tab when the close button is clicked and hide the popup
function openNewTabAndHidePopup() {
  window.open('https://www.example.com', '_blank');
  hidePopup();
}

// Function to toggle the visibility of the image
function toggleImageVisibility() {
  var image = document.getElementById('popupImage');
  if (image.style.display === 'none') {
    image.style.display = 'block';
  } else {
    image.style.display = 'none';
  }
}

// Call the showPopup function after 5 seconds initially
setTimeout(showPopup, 5000);

// Add event listener to the image to open a new tab and hide the popup
document.getElementById('popupImage').addEventListener('click', openNewTabAndHidePopup);

// Add event listener to the image to toggle its visibility
document.getElementById('popupImage').addEventListener('click', toggleImageVisibility);
